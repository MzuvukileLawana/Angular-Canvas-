﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Contracts;
using Entities.Models;
using Microsoft.AspNetCore.Mvc;

namespace AbsaAssessment.Controllers
{
    [Route("api/flight")]
    public class BookFlightController : Controller
    {
        private ILoggerManager _logger;
        private IRepositoryWrapper _repository;

        public BookFlightController(ILoggerManager logger, IRepositoryWrapper repository)
        {
            _logger = logger;
            _repository = repository;
        }

        [HttpGet]
        public IActionResult GetAllBookFlight()
        {
            try
            {
                var bookFlights = _repository.BookFlight.GetAllBookFlight();

                _logger.LogInfo($"Returned all booked flights from database.");

                return Ok(bookFlights);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong inside GetAllBookFlight action: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpPost]
        public IActionResult CreateBookFlight([FromBody]BookFlight bookFlight)
        {
            try
            {
                if (bookFlight == null)
                {
                    _logger.LogError("BookFlight object sent from client is null.");
                    return BadRequest("BookFlight object is null");
                }

                if (!ModelState.IsValid)
                {
                    _logger.LogError("Invalid bookFlight object sent from client.");
                    return BadRequest("Invalid model object");
                }

                _repository.BookFlight.CreateBookFlight(bookFlight);

                return CreatedAtRoute("bookFlightById", new { id = bookFlight.Id }, bookFlight);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong inside CreateBookFlight action: {ex.Message}");
                return StatusCode(500, "Internal server error");
            }
        }


    }
}
