﻿using Contracts;
using Entities;
using Entities.Extenals;
using Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace Repository
{
    class BookFlightRepository : RepositoryBase<BookFlight>, IBookFlightRepository
    {
        public BookFlightRepository(RepositoryContext repositoryContext)
            : base(repositoryContext)
        {
        }

        public IEnumerable<BookFlight> GetAllBookFlight()
        {
            return FindAll()
                .OrderBy(ow => ow.From);
        }
        public BookFlight GetBookFlightId(int bookFlightId)
        {
            return FindByCondition(bookFlight => bookFlight.Id.Equals(bookFlightId))
                    .FirstOrDefault();
        }
        public void CreateBookFlight(BookFlight bookFlight)
        {
            bookFlight.Id = new Int16();
            Create(bookFlight);
            Save();
        }
        public void UpdateBookFlight(BookFlight dbBookFlight, BookFlight bookFlight)
        {
            dbBookFlight.Map(bookFlight);
            Update(dbBookFlight);
            Save();
        }
        public void DeleteEmployee(BookFlight bookFlight)
        {
            Delete(bookFlight);
            Save();
        }

        public BookFlight GetBookFlightById(int bookFlightId)
        {
            throw new NotImplementedException();
        }

        public void DeleteBookFlight(BookFlight bookFlight)
        {
            throw new NotImplementedException();
        }
    }
}
