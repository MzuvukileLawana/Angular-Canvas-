﻿using System;
using System.Collections.Generic;
using System.Text;
using Contracts;
using Entities;

namespace Repository
{
    public class RepositoryWrapper : IRepositoryWrapper
    {
        private RepositoryContext _repoContext;
        private IBookFlightRepository _bookFlight;


        public IBookFlightRepository BookFlight
        {
            get
            {
                if (_bookFlight == null)
                {
                    _bookFlight = new BookFlightRepository(_repoContext);
                }

                return _bookFlight;
            }
        }

        //public IEmployeeRepository Employee => throw new NotImplementedException();

        public RepositoryWrapper(RepositoryContext repositoryContext)
        {
            _repoContext = repositoryContext;
        }
    }
}
