﻿using System;
using Entities.Models;
using System.Collections.Generic;

namespace Contracts
{
    public interface IBookFlightRepository : IRepositoryBase<BookFlight>
    {
        IEnumerable<BookFlight> GetAllBookFlight();
        BookFlight GetBookFlightById(int bookFlightId);
        void CreateBookFlight(BookFlight bookFlight);
        void UpdateBookFlight(BookFlight dbBookFlight, BookFlight bookFlight);
        void DeleteBookFlight(BookFlight bookFlight);
    }
}
