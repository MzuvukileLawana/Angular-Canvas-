﻿using System;
using System.Collections.Generic;
using System.Text;
using Entities.Models;

namespace Entities.Extenals
{
    public static class BookFlightExtensions
    {
        public static void Map(this BookFlight dbBookFlight, BookFlight bookFlight)
        {
            dbBookFlight.From = bookFlight.From;
            dbBookFlight.To = bookFlight.To;
            dbBookFlight.DepartureDate = bookFlight.DepartureDate;
            dbBookFlight.ReturnDate = bookFlight.ReturnDate;
            dbBookFlight.Adults = bookFlight.Adults;
            dbBookFlight.Children = bookFlight.Children;
        }
    }
}
