import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { BookFlight } from '../models/book-fight-model';




@Injectable()
export class DatabaseServiceService {
  url = "http://localhost:60902/api/";

  constructor(private httpClient: HttpClient) { }

  public getFlight() {
   
    debugger;
   return this.httpClient.get(this.url + 'flight', {headers : this.getBasicHeaders()}).pipe(
          map((res: any) => res),
          catchError(this.handleError)
      );
  }
  public saveFlightBooking(bookFlight: BookFlight){
   
    debugger;
   return this.httpClient.post(this.url + 'flight',bookFlight, {headers : this.getBasicHeaders()}).pipe(
          map((res: any) => res),
          catchError(this.handleError)
      );
  }
  private getBasicHeaders(): HttpHeaders {
    var headers = new HttpHeaders();
    headers.append('Access-Control-Allow-Origin', '*');
    headers.append('Content-Type', 'application/json');
    // You can append more information on the headers here such as Authorization bearer token
    // for example headers.append('Authorization', 'Bearer ' + SecurityService.AccessToken)
    // but for this to happen, don't forget the relevant services
    return headers;
}

private handleError(err) {
    let errorMessage: string;
    if (err.error instanceof ErrorEvent) {
        errorMessage = 'An error occurred: ' + err.error.message;
    } else {
        errorMessage = err.status + ' ' + err.message;
    }
    console.error(err);
    return throwError(errorMessage);
}

}
