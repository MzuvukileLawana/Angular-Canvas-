import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-hotel-form',
  templateUrl: './search-hotel-form.component.html',
  styleUrls: ['./search-hotel-form.component.css']
})
export class SearchHotelFormComponent implements OnInit {
  today = new Date();
  constructor() { }

  ngOnInit() {
  }

}
