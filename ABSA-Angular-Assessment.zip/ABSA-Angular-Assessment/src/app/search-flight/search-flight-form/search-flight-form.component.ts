import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-flight-form',
  templateUrl: './search-flight-form.component.html',
  styleUrls: ['./search-flight-form.component.css']
})
export class SearchFlightFormComponent implements OnInit {
  today = new Date();
  constructor() { }

  ngOnInit() {
  }

}
