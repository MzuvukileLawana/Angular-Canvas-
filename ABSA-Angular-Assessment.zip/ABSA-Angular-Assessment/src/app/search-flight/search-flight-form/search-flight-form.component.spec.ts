import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchFlightFormComponent } from './search-flight-form.component';

describe('SearchFlightFormComponent', () => {
  let component: SearchFlightFormComponent;
  let fixture: ComponentFixture<SearchFlightFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchFlightFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFlightFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
