import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlightsHotelsBookingComponent } from './flights-hotels-booking.component';

describe('FlightsHotelsListComponent', () => {
  let component: FlightsHotelsBookingComponent;
  let fixture: ComponentFixture<FlightsHotelsBookingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlightsHotelsBookingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlightsHotelsBookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
