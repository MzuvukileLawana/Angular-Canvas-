import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import {DatabaseServiceService} from '../../shared/service/database-service.service';
import { BookFlight } from 'src/app/shared/models/book-fight-model';

@Component({
  selector: 'app-flights-hotels-booking',
  templateUrl: './flights-hotels-booking.component.html',
  styleUrls: ['./flights-hotels-booking.component.css']
})
export class FlightsHotelsBookingComponent implements OnInit {
today = new Date();
saveFlight: FormGroup;
  constructor( private formBuilder: FormBuilder, private service: DatabaseServiceService) { }

  ngOnInit() {
    this.getFormBuilder()
  }

  getFormBuilder(){
    this.saveFlight = this.formBuilder.group({
      from: ['', Validators.required],
      to: ['', Validators.required],
      departureDate: ['', Validators.required],
      returnDate: ['', Validators.required],
      adults: ['',  Validators.required ],
      children: [ '',Validators.required ],
    });
  }
  
  get saveFormReadControls() {
    return this.saveFlight.controls;
  }

onSubmit(){
  debugger
  if (this.saveFlight.valid) {
    this.executeBookingFlight();
  }
}
executeBookingFlight() {
  let bookFlight: BookFlight = {
    id: 0,
    from : this.saveFormReadControls.from.value,
    to : this.saveFormReadControls.to.value,
    departureDate : this.saveFormReadControls.departureDate.value,
    returnDate : this.saveFormReadControls.returnDate.value,
    adults: this.saveFormReadControls.adults.value,
    children: this.saveFormReadControls.children.value
  }
debugger;
  this.service.saveFlightBooking(bookFlight).subscribe(resp => {
    console.log(resp);
    });
}
}
