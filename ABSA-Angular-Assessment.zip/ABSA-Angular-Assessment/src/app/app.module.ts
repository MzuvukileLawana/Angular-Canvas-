import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MatTabsModule, MatIconModule, MatFormFieldModule,MatInputModule,MatDatepickerModule,MatNativeDateModule, MatExpansionModule } from '@angular/material';
import { SearchFlightFormComponent } from './search-flight/search-flight-form/search-flight-form.component';
import { SearchHotelFormComponent } from './search-hotel/search-hotel-form/search-hotel-form.component';
import { FlightsHotelsBookingComponent } from './flights-hotels/flights-hotels-booking/flights-hotels-booking.component'; 
import { DatabaseServiceService } from './shared/service/database-service.service';
import{HttpClientModule} from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
const appRoutes: Routes = [
  { path: 'home', component: AppComponent},
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: '**', redirectTo: 'home' },
];

@NgModule({
  declarations: [
    AppComponent,
    SearchFlightFormComponent,
    SearchHotelFormComponent,
    FlightsHotelsBookingComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatTabsModule,
    HttpClientModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatExpansionModule,
    ReactiveFormsModule ,
    FormsModule ,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [DatabaseServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
