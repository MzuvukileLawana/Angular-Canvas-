import { Component } from '@angular/core';
import {DatabaseServiceService} from './shared/service/database-service.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ABSA-Angular-Assessment';

  constructor(private service: DatabaseServiceService){}

  ngOnInit(): void {
 
     this.service.getFlight().subscribe(resp => {
    console.log(resp);
    });
  }
}
