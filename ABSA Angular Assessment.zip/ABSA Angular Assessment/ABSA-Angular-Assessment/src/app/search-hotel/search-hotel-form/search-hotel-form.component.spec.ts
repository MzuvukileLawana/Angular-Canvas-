import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchHotelFormComponent } from './search-hotel-form.component';

describe('SearchHotelFormComponent', () => {
  let component: SearchHotelFormComponent;
  let fixture: ComponentFixture<SearchHotelFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchHotelFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchHotelFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
