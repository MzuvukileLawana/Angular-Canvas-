export interface BookFlight {
    id: number;
    from: string;
    to: string;
    departureDate: Date;
    returnDate: Date;
    adults: string;
    children: string
    }
    